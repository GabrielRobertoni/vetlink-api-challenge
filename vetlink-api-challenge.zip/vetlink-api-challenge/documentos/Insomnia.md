//Execute na ordem de classes!!

//TUTORES
![img.png](Insomnia_tutores_post.png)
![img.png](Insomnia_tutores_get.png)
![img.png](Insomnia_tutores_put.png)
![img.png](Insomnia_tutores_delete.png)

//CLINICA
![img.png](Insomnia_clinica_post.png)
![img.png](Insomnia_clinica_get.png)
![img.png](Insomnia_clinica_put.png)
![img.png](Insomnia_clinica_delete.png)

//PET
![img.png](Insomnia_pet_post.png)
![img.png](Insomnia_pet_get.png)
![img.png](Insomnia_pet_put.png)
![img.png](Insomnia_pet_delete.png)

//VETERINARIO
![img.png](Insomnia_veterinario_post.png)
![img.png](Insomnia_veterinario_get.png)
![img.png](Insomnia_veterinario_put.png)
![img.png](Insomnia_veterinario_delete.png)

//CONSULTAS
![img.png](Insomnia_consultas_post.png)
![img.png](Insomnia_consultas_get.png)

//EXAME
![img.png](Insomnia_exame_get.png)
![img.png](Insomnia_exame_post.png)

//VACINAS
![img.png](Insomnia_vacinas_post.png)
![img.png](Insomnia_vacinas_get.png)

//MEDICAMENTOS
![img.png](Insomnia_medicamentos_post.png)
![img.png](Insomnia_medicamentos_get.png)

//ASSINATURA
![img.png](Insomnia_assinatura_post.png)
![img.png](Insomnia_assinatura_get.png)
